package com.itheima.d1_unchange_collection;

import java.util.*;

public class Main {
    public static void main(String[] args){
      /*
      随机，Random
      不重复，Set
      排序，TreeSet,
       */
        Scanner s=new Scanner(System.in);
        Random r=new Random();
        r.nextInt(500);//[1,500]



    }
}
