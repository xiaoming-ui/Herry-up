package com.itheima.d4_constant;

/**
    目标：学会常量的使用，并理解常量。
 */
public class ConstantDemo1 {
    public static final String SCHOOL_NAME = "传智集团";
    public static final String USER_NAME = "itheima";
    public static final String PASS_WORD = "123456";

    public static void main(String[] args) {
        System.out.println(SCHOOL_NAME);
        System.out.println(SCHOOL_NAME);
        System.out.println(SCHOOL_NAME);
        System.out.println(SCHOOL_NAME);
        System.out.println(SCHOOL_NAME);
        System.out.println(SCHOOL_NAME);

        if(USER_NAME.equals("")){

        }
    }
}
