package com.itheima.d1_package.demo2;

public class Cat {
    public void run(){
        System.out.println("猫2跑的贼快~~");
    }
}
