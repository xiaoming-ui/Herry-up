package com.itheima.d4_polymorphic_test;

public interface USB {
    void connect();
    void unconnect();
}
