package com.itheima.d2_stream;

import java.util.Scanner;

public class Imitate {
    public static void main(String[] args) {
        /*
        输入一串字符串，输出最后一个单词的长度，
        句子拆分为单词
        最后一个单词的长度
         */
        Scanner s=new Scanner(System.in);
       String str1= s.next();
        System.out.println(str1);
        String[] strings=str1.split(" ");
        System.out.println(strings[strings.length - 1].length());



        }


}
