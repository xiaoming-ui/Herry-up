package com.itheima.d12_interface_extends;

public interface Law {
    void rule(); // 遵章守法
    void eat();
}
