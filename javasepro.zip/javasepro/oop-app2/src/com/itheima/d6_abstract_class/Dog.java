package com.itheima.d6_abstract_class;

public class Dog extends Animal{
    @Override
    public void run() {
        System.out.println("狗跑的也很快~~~");
    }
}
