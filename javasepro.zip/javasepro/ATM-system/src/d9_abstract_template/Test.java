package d9_abstract_template;

public class Test {

    public static void main(String[] args) {
        StudentChilld sd=new StudentChilld();
        StudentsMiddle sd1=new StudentsMiddle();
        //调用的父类模板方法
        sd1.write();
    }
}
