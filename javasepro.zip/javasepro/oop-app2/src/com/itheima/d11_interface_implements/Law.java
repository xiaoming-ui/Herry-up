package com.itheima.d11_interface_implements;

public interface Law {
    void rule(); // 遵章守法
}
