package com.itheima.d1_package.demo1;

public class Cat {
    public void run(){
        System.out.println("猫1跑的贼溜~~");
    }
}
