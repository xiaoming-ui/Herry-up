package com.itheima.d10_genericity_interface;

public interface Data<E> {//泛型接口，接口中方法的参数类型，可以是任意
    void add(E e);
    void delete(int id);
    void update(E e);
    E queryById(int id);
}
