package com.itheima.d1_collection_set;

import java.util.Comparator;
import java.util.Objects;

public class Examinee implements Comparable<Examinee>{
    private int num;
    private float score;

    public Examinee() {
    }

    public Examinee(int num, float score) {
        this.num = num;
        this.score = score;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }




    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Examinee examinee = (Examinee) o;
        return num == examinee.num && Float.compare(examinee.score, score) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(num, score);
    }

    @Override
    public String toString() {
        return "Examinee{" +
                "num=" + num +
                ", score=" + score +
                '}';
    }

    /**
     * o1.compareTo(o)
     * @param o
     * @return
     */
    @Override
    public int compareTo(Examinee o) {
        return  Float.compare(this.getScore(),o.getScore());
    }
}
