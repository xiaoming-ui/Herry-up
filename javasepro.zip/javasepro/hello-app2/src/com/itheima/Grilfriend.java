package com.itheima;

public class Grilfriend {
    private String name;
    private double height;
    private double weight;

    public Grilfriend(String name, double height, double weight) {
        this.name = name;
        this.height = height;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void wash()
    {
        System.out.println(this.name+"is washing for me.");
    }
    public void cook()
    {
        System.out.println(this.name+"is cooking for me.");
    }
    public void show()
    {
        System.out.println("My girlfriend is " + this.name + ".Her height is"
                + this.height + "and her weight is"
                + this.weight + ".");
    }
}
