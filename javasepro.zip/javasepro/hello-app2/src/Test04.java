import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Test04 {
    public static void main(String[] args) {
        //开账户，存入到ArrayList
        ArrayList<Account> list = new ArrayList<>();
        //登陆，注册
        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("1、 注册\n2、登陆");
            String str = s.next();
            switch (str) {
                case "1":
                    //注册
                    register(list, s);
                    break;
                case "2":
                    //登陆
                    land(list, s);
                    break;
                default:
                    System.out.println("输入不合法请重新输入");
            }
        }
    }

    /**
     * 登陆，账号密码，匹配
     *
     * @param list 银行账户库，null, size==0,
     * @param s    扫描器
     */
    private static void land(ArrayList<Account> list, Scanner s) {
        if (list == null || list.size() == 0) {
            System.out.println("现在银行账号中没有账户");
        }
        System.out.println("请输入账号");
        String str1 = s.next();
        Account ac = exist(list, str1);
        if (ac != null)//找到账户
        {
            System.out.println("请输入密码");
            String str2 = s.next();
            //账号和密码匹配
            if (checkAccount(ac, str2)) {

                service(list, ac, s);
                //业务，存钱，取钱
            } else {
                System.out.println("密码错误");
            }
        } else {
            System.out.println("不存在此账户");
        }


    }

    /**
     * 服务，
     *
     * @param list 银行系统
     * @param ac   单个账户
     * @param s    扫描器
     */
    private static void service(ArrayList<Account> list, Account ac, Scanner s) {
        System.out.println("=======欢迎您进入黑马银行用户操作界面=========");

        while (true) {
            System.out.println("1、查询\n2、存款\n3、取款\n4、转账\n5、修改密码\n6、退出\n7、注销当前账户");

            String str1 = s.next();
            switch (str1) {
                case "1"://查询
                    query(ac);
                    break;
                case "2"://存款
                    deposit(ac, s);
                    break;
                case "3"://取款
                    withdrawMoney(ac, s);
                    break;
                case "4"://转账
                    transferAccount(list, ac, s);
                    break;
                case "5"://修改密码
                    changePassword(ac, s);
                    break;
                case "6"://退出
                    return;
                case "7"://注销当前账户
                    closeAccount(list, ac,s);
                    return;
                default:
                    System.out.println("您可以继续选择功能进行操作");
            }
        }
    }

    /**
     * 销户
     * @param list 银行系统
     * @param ac 当前账户
     * @param s 扫描器
     */
    private static void closeAccount(ArrayList<Account> list, Account ac,Scanner s) {
        System.out.println("确定要销户吗y/n");
        String str1=s.next();
        if (str1.equals("y"))
        {
            list.remove(ac);
            System.out.println("销户成功");//应该跳转到首页，登陆，注册
            return;
        }
        else
        {
            System.out.println("未成功销户");
            return ;
        }


    }

    /**
     * 改变密码
     *
     * @param ac 当前账户
     * @param s  扫描器
     */
    private static void changePassword(Account ac, Scanner s) {
        // 密码的确认判断
        System.out.println("输入当前密码");
        String str1 = s.next();
        if (str1.equals(ac.getPassword())) {
            while (true) {
                System.out.println("输入新密码");
                String password = s.next();
                System.out.println("再次输入新密码");
                String okPassword = s.next();
                if (password.equals(okPassword)) {
                    ac.setPassword(password);
                    System.out.println("修改密码成功");
                    return;
                } else {
                    System.out.println("两次输入密码不一致，请重新输入");
                }
            }
        } else {
            System.out.println("输入密码不正确");
        }

    }

    /**
     * 转账
     *
     * @param list 银行系统
     * @param ac   单个账户
     * @param s    扫描器
     */
    private static void transferAccount(ArrayList<Account> list, Account ac, Scanner s) {
        //输入要转账的账号，条件：系统一共有大于等于2个账户，存在，不能是自己的账户
        //转账金额，小于等于自己的存款，小于单笔交易限制
        //输入对方的姓氏，字符串取子串，判断
        if (list.size() < 2) {
            System.out.println("当前银行系统账户不足2个，不能够进行转账业务");
            return;
        }
        System.out.println("请输入要转账的账号");
        String str1 = s.next();
        Account ac2 = exist(list, str1);
        if (ac == ac2) {
            System.out.println("您不能用当前账户转账给当前账户，转账失败");
        } else if (ac2 == null) {
            System.out.println("账号不存在,转账失败");
        } else {
            System.out.println("请输入转账金额");
            float f1 = s.nextFloat();
            if (f1 > ac.getBalance()) {
                System.out.println("转账金额大于余额,转账失败");
            } else if (f1 > ac.getLimit()) {
                System.out.println("转账金额大于单笔交易限制.转账失败");
            } else {

                //输入转账方的姓氏
                System.out.println("请输入转账方的姓氏*" + ac2.getName().substring(1));
                String str2 = s.next();
                String str3 = ac2.getName().substring(0, 1);
                if (str3.equals(str2)) {
                    change(ac, -f1);
                    change(ac2, f1);
                } else {
                    System.out.println("输入姓氏错误，转账失败");
                }

            }


        }


    }

    /**
     * 取钱
     *
     * @param ac 账户
     * @param s  变动金额
     */
    private static void withdrawMoney(Account ac, Scanner s) {
        while (true) {
            System.out.println("请输入要取出的金额");
            float f2 = s.nextFloat();
            if (f2 > ac.getBalance()) {
                System.out.println("您输入的金额大于您的存款，请重新输入");
            }
            if (f2 > ac.getLimit()) {
                System.out.println("您输入的金额大于单词取款限额，请重新输入");
            } else {
                change(ac, -f2);
                return;
            }

        }
    }

    /**
     * 存钱，
     *
     * @param ac 账户
     * @param s  扫描器
     */
    private static void deposit(Account ac, Scanner s) {
        System.out.println("请输入要存入的金额");
        float f1 = s.nextFloat();
        change(ac, f1);
    }

    /**
     * 改变账户的金额
     *
     * @param ac 账户
     * @param f1 改变的金额
     */
    private static void change(Account ac, float f1) {
        ac.setBalance(ac.getBalance() + f1);
        System.out.println("交易成功");
    }

    //显示用户信息，
    private static void query(Account ac) {
        System.out.println("您的账户信息如下：");
        System.out.println("卡号:" + ac.getNumber());
        System.out.println("姓名:" + ac.getName());
        System.out.println("余额:" + ac.getBalance());
        System.out.println("单次取现额度:" + ac.getLimit());
    }

    /**
     * 检查密码是否为当前账户的密码
     *
     * @param ac   账户 !=null
     * @param str2 密码
     */
    private static boolean checkAccount(Account ac, String str2) {
        boolean ret = false;
        if (str2 != null && str2.length() >= 0) {
            ret = str2.equals(ac.getPassword());
        }
        return ret;
    }

    /**
     * 注册
     *
     * @param list
     */
    private static void register(ArrayList<Account> list, Scanner s) {
        System.out.println();
        //随机生产账号，不重复
        //输入密码，再次输入密码
        Random r = new Random();

        while (true) {
            String str = "";
            for (int i = 0; i < 8; i++) {
                str += r.nextInt(10);
            }
            //检查账号是否重复
            if (exist(list, str) == null) {
                //继续输入密码，确认密码
                //添加到集合
                while (true) {
                    System.out.println("输入密码");
                    String password = s.next();
                    System.out.println("再次输入密码");
                    String okPassword = s.next();
                    if (okPassword.equals(password)) {
                        //添加到集合
                        System.out.println("用户名");
                        String str1 = s.next();
                        System.out.println("取钱限制");
                        float f = s.nextFloat();
                        Account a = new Account();
                        a.setNumber(str);//账号
                        a.setName(str1);//用户名
                        a.setLimit(f);//取钱限制
                        a.setPassword(password);//密码
                        list.add(a);
                        System.out.println("注册成功,您的账号为" + a.getNumber() + "用户名" + a.getName() + "取钱限制" + a.getLimit());
                        break;
                    } else {
                        System.out.println("密码不一致");
                    }
                }
                break;
            }
        }


    }


    /**
     * 检查是否存在，存在返回元素，不存在返回 null
     *
     * @param list 账号数组
     * @param s    账号
     * @return account
     */
    private static Account exist(ArrayList<Account> list, String s) {
        if (s != null) {
            for (int i = 0; i < list.size(); i++) {
                if (s.equals(list.get(i).getNumber())) {
                    return list.get(i);
                }
            }
        }
        return null;
    }

}