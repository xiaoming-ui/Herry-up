package com.itheima.d4;

public class KeyBoard implements USB {
    String name;

    public KeyBoard(String name) {
        this.name = name;
    }
    //独有功能
    public void keyDown()
    {
        System.out.println("写下来，给我冲！");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void connect() {
        System.out.println(name+"连接成功");
    }

    @Override
    public void signOut() {
        System.out.println(name+"成功退出");
    }
}
