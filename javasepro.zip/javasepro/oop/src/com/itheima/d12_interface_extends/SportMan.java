package com.itheima.d12_interface_extends;

public interface SportMan extends Law, People {
    void run();
    void competition();
}
