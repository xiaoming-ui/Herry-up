package com.itheima.d13_extends_constructor2;

public class Student extends People{
    private String className;

    public Student(){
    }

    public Student(String name, int age, String className) {
        super(name, age);//初始化从 父类继承过来的成员变量，调用父类构造器
        this.className = className;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}
