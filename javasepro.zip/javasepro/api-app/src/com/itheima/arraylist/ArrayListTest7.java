package com.itheima.arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListTest7 {
    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        ArrayList<Student> students=new ArrayList<>();
//        students.add(new Student("20180302","叶孤城",23,"护理一班"));
//        students.add(new Student("20180303","东方不败",23,"推拿二班"));
//        students.add(new Student( "20180304","西门吹雪",26,"中药学四班"));
//        students.add(new Student( "20180305","梅超风",26,"神经科2班"));
//        // 3、遍历集合中的每个学生对象并展示其数据
//        show(students);
//        while (true) {
//            System.out.println("请输入要查找的学号");
//            String s=sc.next();
//            if (find(students,s)!=null)
//            {
//                Student st=find(students,s);
//                System.out.println(st.getStudyId()+"\t"+st.getName());
//            }
//            else
//            {
//                System.out.println("不存在此学号");
//            }
//        }
        String s1=new String("abc");
        String s2="aBb";
        System.out.println(s1.equalsIgnoreCase(s2));

    }
    //遍历输出显示
    public static void show(ArrayList<Student> students)
    {
        System.out.println("学号\t姓名\t年龄\t班级");
        for (int i = 0; i < students.size(); i++) {
            Student s=students.get(i);

            System.out.println(s.getStudyId()+"\t"+s.getName()
                    +"\t"+s.getAge()+"\t"+s.getClassName());

        }
    }

    //通过学号查找
    public static Student find(ArrayList<Student> students,String s)
    {
        for (int i = 0; i < students.size(); i++) {
            Student st=students.get(i);
            if(st.getStudyId().equals(s))
            {
                return students.get(i);
            }
        }
        return null;
    }

}
