package com.itheima.d12_extends_constructor;

public class Animal {
    public Animal(){
        System.out.println("==父类Animal无参数构造器被执行===");
    }
}
