package com.itheima.d4;

public interface USB {
    //连接、退出
      void connect();
     void signOut();
}
