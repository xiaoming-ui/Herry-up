public enum Season {
    SPRING,SUMMER,AUTUMN,WINTER;
}
/*反编译
public final class Season extends java.lang.Enum<Season> {
    public static final Season SPRING;
    public static final Season SUMMER;
    public static final Season AUTUMN;
    public static final Season WINTER;
    public static Season[] values();
    public static Season valueOf(java.lang.String);
    static {};
}
 */

