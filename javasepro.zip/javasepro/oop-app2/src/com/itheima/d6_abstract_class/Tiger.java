package com.itheima.d6_abstract_class;

public class Tiger extends Animal{
    @Override
    public void run() {
        System.out.println("老虎跑的贼溜~~~~");
    }
}
