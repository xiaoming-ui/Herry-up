package com.itheima.d12_interface_extends;

public interface SportMan extends Law, People {//接口支持多继承
    void run();
    void competition();
}
