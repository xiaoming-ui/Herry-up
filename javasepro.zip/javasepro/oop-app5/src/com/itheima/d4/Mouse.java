package com.itheima.d4;

public class Mouse implements USB{
   private String name;

    public Mouse(String name) {
        this.name = name;
    }

    public void dbClick()
   {
       System.out.println("一键三连！");
   }

    @Override
    public void connect() {
        System.out.println(name+"连接成功");
    }

    @Override
    public void signOut() {
        System.out.println(name+"成功退出");
    }
}
