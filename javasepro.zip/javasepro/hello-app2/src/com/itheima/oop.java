package com.itheima;

import java.util.ArrayList;

public class oop {
    public static void main(String[] args) {
        /*
        定义一个女朋友类。女朋友的属性包含：姓名，身高，体重。
        行为包含：洗衣服wash()，做饭cook()。
        另外定义一个用于展示三个属性值的show()方法。
        请在测试类中通过有参构造方法创建对象并赋值，
        然后分别调用展示方法、洗衣服方法和做饭方法。打印效果如下：
        * */

        ArrayList<String> s=new ArrayList<>();
        s.add("Fire");
        s.add("前途命运，自己掌握");
        for (int i = 0; i < s.size(); i++) {
            System.out.println(s);
        }

    }
}
