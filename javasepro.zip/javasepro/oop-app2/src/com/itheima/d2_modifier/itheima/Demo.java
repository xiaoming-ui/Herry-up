package com.itheima.d2_modifier.itheima;


import com.itheima.d2_modifier.itcast.Fu;

public class Demo {

    public static void main(String[] args) {
        //创建Fu的对象，测试看有哪些方法可以使用
        Fu f = new Fu();
        f.show4();
    }

}
