package com.itheima.d1_package.demo1;

public class Animal {
}
