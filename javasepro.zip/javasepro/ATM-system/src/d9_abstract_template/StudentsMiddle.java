package d9_abstract_template;

public class StudentsMiddle extends Student{


    @Override
    public String writeMain() {
        return "我的爸爸也很很牛，吃饭不愁。";
    }
}
