public class NewPhone extends Phone {
    public static void main(String[] args) {
        NewPhone n=new NewPhone();
        n.call();
    }
    @Override
    public void call()
    {
        super.call();
        System.out.println("视频通话");
    }
    public void sendMeg()
    {
        System.out.println("发送语音和图片");
    }

}
class Phone
{
    public void call(){
        System.out.println("打电话");
    }
    public void sendMeg()
    {
        System.out.println("发短信");
    }
}
