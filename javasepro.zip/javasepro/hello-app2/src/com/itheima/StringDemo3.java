package com.itheima;

import org.w3c.dom.ls.LSOutput;

public class StringDemo3 {


    public static void main(String[] args) {
        String a1="abc";
        String a2="a"+"b"+"c";
        System.out.println(a1==a2);
    }
}
