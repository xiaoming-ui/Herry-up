package com.itheima;

public class SingleInstance {
    /**
     * 2、定义一个静态成员变量负责存储一个对象，
     * 只加载一次，只有一份
     * 最好私有化，避免给别人挖坑！别人调用的避免是null
     */
    private static SingleInstance instance;
    //3、提供一个方法对外返回单例对象
    public static SingleInstance getInstance()
    {
        if(instance==null)
        {//第一次来拿对象，此时需要创建对象
            instance=new SingleInstance();
        }
        return instance;
    }
    //1、私有化构造器
   private  SingleInstance() {

    }

}
