public class Student extends People{
    @Override
    public void eat() {
        super.eat();
        System.out.println("学生要吃东西，补充能量来学习");
    }
}
class People{
    public  void eat()
    {
        System.out.println("吃东西");
    }
}
