package com.itheima.d9_map_impl;

import java.util.*;

public class Imitate {
    public static void main(String[] args) {
        HashMap<String,List<String>> h=new HashMap<>();
        List<String> select1=new ArrayList<>();
        Collections.addAll(select1,"A","B","C");
        h.put("张",select1);

        List<String> select2=new ArrayList<>();
        Collections.addAll(select2,"C","D");
        h.put("刘",select2);

        List<String> select3=new ArrayList<>();
        Collections.addAll(select3,"A","C");
        h.put("文",select3);

        Collection<List<String>> values=h.values();
        //[[A,B],[C]]
        //新的结构，[景点,票数],建议先理解代码，画图来理解
        HashMap<String,Integer> info=new HashMap<>();
        for (List<String> value : values) {
            for (String s : value) {
                if (info.containsKey(s))
                {
                    info.put(s,info.get(s)+1);
                }
                else
                {
                    info.put(s,1);
                }
            }

        }
        System.out.println(info);


    }


}
