package com.itheima.d12_interface_extends;

/**
   实现类
 */
// public class BasketballMan implements Law, SportMan, People {
public class BasketballMan implements SportMan{

    @Override
    public void rule() {

    }

    @Override
    public void eat() {

    }


    @Override
    public void run() {

    }

    @Override
    public void competition() {

    }
}
