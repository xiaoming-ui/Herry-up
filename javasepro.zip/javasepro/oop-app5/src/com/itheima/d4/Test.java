package com.itheima.d4;

public class Test {
    /**
     目标：USB设备模拟
     1、定义USB接口：接入 拔出
     2、定义2个USB的实现类：鼠标、键盘。
     3、创建一个电脑对象，创建USB设备对象，安装启动。
     */
    public static void main(String[] args) {
        Computer cm=new Computer();
        USB u1=new KeyBoard("罗技");


        cm.installUSB(u1);
        System.out.println("---------");
        USB u2=new Mouse("索尼");
        cm.installUSB(u2);
    }

}
