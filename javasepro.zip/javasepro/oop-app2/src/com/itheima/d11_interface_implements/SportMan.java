package com.itheima.d11_interface_implements;

public interface SportMan {
    void run();
    void competition();
}
