package dataStructure;

public class QuickSort {
        public static void main(String[] args) {
            //实现快排
            //测试用例：
            //
            int [] arr={10,5,6,7,8,10};

            for (int i = 0; i < arr.length; i++) {
                System.out.print(arr[i]+" ");
            }
            System.out.println();
            quick_sort(arr,0,arr.length-1);
            for (int i = 0; i < arr.length; i++) {
                System.out.print(arr[i]+" ");
            }


        }

        public static void quick_sort(int arr[], int l, int r)
        {
            if (l<r)
            {
                //基准
                int i=l,j=r;
                int x=arr[l];
                while (i<j) {
                    while(i<j && arr[j]>=x)
                        j--;
                    if (i<j)
                        arr[i++]=arr[j];
                    while(i<j && arr[i]<=x)
                        i++;
                    if (i<j)
                        arr[j--]=arr[i];
                }
                //i==j
                arr[i]=x;
                quick_sort(arr,l,i-1);
                quick_sort(arr,i+1,r);
            }

        }
}
