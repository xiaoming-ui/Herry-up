package com.itheima.d1_package;

public class Student {
}
