package com.itheima.arraylist;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
   案例：从集合中遍历元素且删除。
 */
public class ArrayListTest4 {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String phone=s.next();
        String s1= phone.substring(0,3);
        String s2=phone.substring(7);
        String s3=s1+"****"+s2;
        System.out.println(s3);


    }
}






