package com.itheima.d4_imitate;

public class Card {
    private String size;//大小
    private String color;//花色
    private int idex;//大小


    public Card() {
    }

    public Card(String size, String color, int idex) {
        this.size = size;
        this.color = color;
        this.idex = idex;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getIdex() {
        return idex;
    }

    public void setIdex(int idex) {
        this.idex = idex;
    }

    @Override
    public String toString() {
        return "Card{" +
                "size='" + size + '\'' +
                ", color='" + color + '\'' +
                '}' + '\n';

    }
}
