package com.itheima.d7_extends;

public class Teacher extends People{
    /**
       独有的行为
     */
    public void teach(){
        System.out.println("老师在快乐的教Java~~~~~");
    }

}
