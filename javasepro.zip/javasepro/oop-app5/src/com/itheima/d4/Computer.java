package com.itheima.d4;

public class Computer {
    //模拟电脑，键盘，鼠标，USB工作
    public void installUSB( USB u)
    {
        //接入
        u.connect();
        if (u instanceof KeyBoard)
        {
            ((KeyBoard) u).keyDown();
        }
        else if (u instanceof Mouse)
        {
            ((Mouse) u).dbClick();
        }
        //弹出
        u.signOut();
    }
}
