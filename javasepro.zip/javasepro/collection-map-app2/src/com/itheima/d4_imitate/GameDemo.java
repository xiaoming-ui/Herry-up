package com.itheima.d4_imitate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GameDemo {
    //个数确定，查，没有增删，无疑ArrayList
    public static List<Card> allCards=new ArrayList<>();

    static{//静态代码块初始化数据
        String[] sizes={"3","4","5","6","7","8","9","10","J","Q","K","A","2"};
        String[] colors={"♠", "♥", "♣", "♦"};
        //增强for遍历
        int idex=0;
        for (String size : sizes) {
            idex++;//[1,13]
            for (String color : colors) {
                Card c=new Card(size,color,idex);
                allCards.add(c);
            }
        }
        //还有大小王
        //13*4+2=54
        Card c1=new Card("","🃏",++idex);
        Card c2=new Card("","👲",++idex);
        Collections.addAll(allCards,c1,c2);
        System.out.println("新牌"+allCards);

    }
    public static void main(String[] args) {
        //洗牌
        Collections.shuffle(allCards);
        System.out.println("洗牌：\n"+allCards);
        //玩家也是个集合，他们有个子的牌
        List<Card> wuji=new ArrayList<>();
        List<Card> duanyu=new ArrayList<>();
        List<Card> qiaofeng=new ArrayList<>();
        //发牌，留三张底牌
        //3次循环发牌，取余
        for (int i = 0; i < allCards.size()-3; i++) {
            Card c1=allCards.get(i);
            if (i%3==0)
            {
                wuji.add(c1);
            }
            else if (i%3==1)
            {
                duanyu.add(c1);
            }
            else if (i%3==2)
            {
                qiaofeng.add(c1);
            }
        }
        //最后三张底牌留在桌子上
        List<Card> lastCards= allCards.subList(allCards.size()-3,allCards.size());
//        给玩家的牌排序
//        大小应该是牌本身具有的，作为属性
        //类实现了接口排序，
        //自定义比较器
        sortCards(wuji);
        sortCards(duanyu);
        sortCards(qiaofeng);
        System.out.println("wuji"+wuji);
        System.out.println("duanyu"+duanyu);
        System.out.println("qiaofeng"+qiaofeng);




    }
    /**
     * 给牌排序
     */
   public static void sortCards(List<Card> cards)
    {
        Collections.sort(cards,( o1, o2)->  o1.getIdex()-o2.getIdex());
    }
}
