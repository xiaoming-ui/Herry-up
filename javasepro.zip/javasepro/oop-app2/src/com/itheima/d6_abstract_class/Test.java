package com.itheima.d6_abstract_class;

public class Test {
    public static void main(String[] args) {
        Tiger t = new Tiger();
        t.run();

        Dog t1 = new Dog();
        t1.run();
    }
}
