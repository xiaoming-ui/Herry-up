package com.itheima.d8_map_test;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Imiate {
    public static void main(String[] args) {
        /*
        投票，接受一个字符串
        键值对，键景点，值投票人数
         */
        StringBuilder sb=new StringBuilder();
        Random r=new Random();
        String scenic="ABCD";
        for (int i=0;i<80;i++ ) {
            sb.append(scenic.charAt(r.nextInt(scenic.length())));
        }
        for (int i = 0; i <sb.length() ; i++) {
            System.out.print(sb.charAt(i));
        }
        System.out.println();
        Map<Character,Integer> h=new HashMap();
//        for (int i = 0; i < scenic.length(); i++) {
//            h.put(scenic.charAt(i),0);
//        }
        //遍历，
//        for (int i = 0; i < 80; i++) {
//            for (int j = 0; j <scenic.length() ; j++) {
//                if (sb.charAt(i)==scenic.charAt(j))
//                {
//                    h.put(scenic.charAt(j),h.get(scenic.charAt(j))+1);
//                }
//            }
//        }
        for (int i=0;i<sb.length();i++)
        {
            char c=sb.charAt(i);
            if (h.containsKey(c))
            {
                h.put(c,h.get(c)+1);
            }
            else
            {//第一次包含
                h.put(c,1);
            }
        }
        System.out.println(h);



    }

}
