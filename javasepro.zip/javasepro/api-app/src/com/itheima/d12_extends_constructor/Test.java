package com.itheima.d12_extends_constructor;

public class Test {
    public static void main(String[] args) {
        Cat c = new Cat();
        System.out.println("------------");
        Cat c1 = new Cat("叮当猫");
    }
}


