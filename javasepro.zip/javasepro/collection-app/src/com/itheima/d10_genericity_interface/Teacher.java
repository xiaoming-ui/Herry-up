package com.itheima.d10_genericity_interface;

public class Teacher {
}
