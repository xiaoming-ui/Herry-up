package d9_abstract_template;

public class StudentChilld extends Student {

    @Override
    public String writeMain() {
        return "我的爸爸很牛，他经常给我买东西吃。";
    }
}
