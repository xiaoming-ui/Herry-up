package com.itheima.d7_map_traversal;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;

public class D1 {
    public static void main(String[] args) {
        Map<String,Integer> m=new HashMap<>();
        //无序，无索引，
        m.put("张来明",6);
        m.put("加油",38);
        m.put("没问题的",39);
        System.out.println(m);
        //遍历1
        Set<String> keys=m.keySet();
        for (String key : keys) {
            System.out.println(key +"==》"+m.get(key));
        }
        System.out.println("遍历2-------------");
        //遍历2
        Set<Map.Entry<String, Integer>> entries = m.entrySet();

        for (Map.Entry<String, Integer> entry : entries) {
            String key=entry.getKey();
            Integer value=entry.getValue();
            System.out.println(key+"==>"+value);
        }
        //遍历3
        System.out.println("遍历3-----------------");
        m.forEach(( s,  integer)->System.out.println(s+"==>"+integer));







    }

}
