package com.itheima.d12_interface_extends;

public interface People {
    void eat();
}
