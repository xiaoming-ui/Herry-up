package d9_abstract_template;

public abstract class Student {
    //声明模板方法模式
    //final，防止被子类重写，就是直接让子类用，精简代码的
    public final void write()
    {
        System.out.println("\t\t\t我的爸爸");
        System.out.println("你的爸爸是啥样？");
        //正文部分，每个子类情况都不一样，
        //正文部分定义为抽象方法，交给具体的子类来完成
        System.out.println(writeMain());
        System.out.println("我的爸爸太好了");
    }
    public abstract String writeMain();
}
