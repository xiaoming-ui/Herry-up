package com.itheima.arraylist;


import java.util.*;

/**
 * 目标: 创建ArrayList对象，代表集合容器，往里面添加元素。
 */
public class ArrayListDemo1 {
    public static void main(String[] args) {
//        // 1、创建ArrayList集合的对象
        ArrayList list = new ArrayList();
        ArrayList<String> list1=new ArrayList<>();
//
//        // 2、添加数据
//        list.add("Java");
//        list.add("Java");
//        list.add("MySQL");
//        list.add("黑马");
//        list.add(23);
//        list.add(23.5);
//        list.add(false);
//        System.out.println(list.add('中'));
//        System.out.println(list);
//
//        // 3、给指定索引位置插入元素
        list.add(1, "赵敏");
//        System.out.println(list);
         /*
        多重循环中，java通过标签继续哪个循环或者终止哪个循环
        continue 指定标签继续包围哪个循环
        break label 跳出指定的循环
        * */
        Scanner s=new Scanner(System.in);
        Random r=new Random();
        //红球1-33，不重复，check
        //篮球1-16
        //对比 contrast,两个数组
        //数组
        int[] luck=new int[7];
        int count1=0,count2=0;
        for (int i = 0; i < luck.length-1; ) {
            int data=r.nextInt(33+1);
            if(!exist(luck,data))
            {
                luck[i]=data;
                i++;
            }
        }
        luck[luck.length-1]=r.nextInt(16)+1;

        //用户输入
        int[] guess=new int[7];
        System.out.println("输入猜球数6红球（1-33）1篮球（1-16）");
        for (int i = 0; i < guess.length; i++) {
            guess[i]=s.nextInt();
        }
        printArray(luck);
        printArray(guess);
        count1=check(luck,guess);
        count2=luck[luck.length-1]==guess[guess.length-1]?1:0;
        System.out.println("红球猜对"+count1+"篮球猜对"+count2);

    }
    public static boolean exist(int[] arr,int data)
    {
        boolean ret=false;
        for (int i = 0; i < arr.length; i++) {
            if (data==arr[i])
            {
                ret=true;
                break;
            }
        }
        return ret;
    }
    public static int check(int[] luck,int[] guess)
    {
        //红球
        int count=0;
        for (int i = 0; i < luck.length-1; i++) {
            for (int i1 = 0; i1 < guess.length-1; i1++) {
                if(guess[i1]==luck[i])
                {
                    count++;
                }
            }
        }
        return count;
    }
    public static void printArray(int[] arr)
    {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();
    }
}
