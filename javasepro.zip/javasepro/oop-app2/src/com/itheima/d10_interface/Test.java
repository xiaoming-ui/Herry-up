package com.itheima.d10_interface;

public class Test {
    public static void main(String[] args) {
        // 接口不能创建对象！
//         SportManInterface s = new SportManInterface();
    }
}
