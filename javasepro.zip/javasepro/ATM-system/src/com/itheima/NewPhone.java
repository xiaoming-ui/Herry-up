package com.itheima;

public class NewPhone extends Phone {
    public static void main()
    {
        NewPhone n=new NewPhone();
        n.call();
    }
    //重写的方法
    public void call()
    {
        super.call();
        System.out.println("视频通话");
    }
    public void sedMessage()
    {
        super.sedMessage();
        System.out.println("发送语音和图片");
    }

}

class Phone{

    public void call()
    {
        System.out.println("打电话");
    }
    public void sedMessage()
    {
        System.out.println("发短信");
    }

}
